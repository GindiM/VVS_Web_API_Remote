﻿using System.Net.Sockets;
using System.Net;
using System.Runtime.Loader;

namespace Web_API_Remote_Module
{
    public class Settings
    {
        static public string path = Environment.CurrentDirectory.ToString() + "\\settings.txt";

        static string getIPv4 = GetLocalIPv4();
        static public string content_default = $"ip:{getIPv4}|port:10009|hideConsole:false";
        static public string? content;

        static public string? contentIp;
        static public string? contentPort;
        static public string? ContentHideConsole;

        static public string? ip;
        static public string? port;
        static public string? hideConsole;

        static public void CreateDefaultSettings()
        {
            File.WriteAllText(path, content_default);
            //call this method if settings dont exist
        }
        static public void LoadSettings()
        {
            if (File.Exists(path))
            {
                content = File.ReadAllText(path);
                string[] split = content.Split('|');

                contentIp = split[0];
                contentPort = split[1];
                ContentHideConsole = split[2];

                if (split[0].Contains("ip"))
                {
                    try
                    {
                        string[] str = split[0].Split(":");
                        ip = str[1];
                    }
                    catch { }
                }
                if (split[1].Contains("port"))
                {
                    try
                    {
                        string[] str = split[1].Split(":");
                        port = str[1];
                    }
                    catch { }
                }
                if (split[2].Contains("hideConsole"))
                {
                    try
                    {
                        if (split[2].Contains("true"))
                        {
                            hideConsole = "true";
                        }

                        else
                        {
                            hideConsole = "else";
                        }
                    }
                    catch { }
                }


                //todo: Analize settings here
            }
            else
            {
                CreateDefaultSettings();
                LoadSettings();
            }
        }
        static public string GetComputerHostName()
        {
            return Environment.MachineName;
        }

        static public string GetLocalIPv4()
        {
            string localIPv4 = "null";

            // Get the host name of the local machine
            string hostName = Dns.GetHostName();

            // Get a list of IP addresses associated with the host
            IPAddress[] addresses = Dns.GetHostAddresses(hostName);

            foreach (IPAddress address in addresses)
            {
                if (address.AddressFamily == AddressFamily.InterNetwork)
                {
                    localIPv4 = address.ToString();
                    break;
                }
                
            }

            return localIPv4;
        }

    }
}
