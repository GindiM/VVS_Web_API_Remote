using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore;
using mvcAPI;
using mvcAPI.Controllers;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Xml.Serialization;
using Web_API_Remote_Module;

namespace mvcAPI;
internal class Program
{
    [DllImport("kernel32.dll")]
    private static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    private const int SW_HIDE = 0;
    private const int SW_SHOW = 5;

    static string ip = "null";
    static string port = "null";
    static string hideConsole = "null";
    static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddControllersWithViews();

        var app = builder.Build();




        app.UseDefaultFiles();
        app.UseStaticFiles();
        app.UseRouting();

        app.UseAuthorization();

        app.MapControllerRoute(
            name: "default",
            pattern: "{controller=Home}/{action=Index}/{id?}");






        Settings.LoadSettings();
        ip = Settings.ip;
        port = Settings.port;
        hideConsole = Settings.hideConsole;

        Thread.Sleep(100);

        app.Urls.Add($"http://127.0.0.1:{port}");
        app.Urls.Add($"http://{ip}:{port}");

        if (hideConsole == "true")
        { HideWindow(true); }
        else { HideWindow(false); }


        API.InitiateSessionKicker(120); // Make sure that the Time in the Index.html fits at least 2.5 times inside the specified "seconds" in here


        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Edit Settings.txt file in order to adjust your settings");
        Console.ResetColor();

        app.Run();
    }

    static public void HideWindow(bool trueFalse)
    {
        if (trueFalse)
        {
            IntPtr consoleWindow = GetConsoleWindow();
            ShowWindow(consoleWindow, SW_HIDE);
        }
        else
        {
            IntPtr consoleWindow = GetConsoleWindow();
            ShowWindow(consoleWindow, SW_SHOW);
        }
    }

}






