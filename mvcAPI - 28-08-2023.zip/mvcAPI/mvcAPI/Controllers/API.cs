﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Reflection.Emit;

namespace mvcAPI.Controllers
{
    public class API : Controller
    {
        static public TcpClient client;
        static public NetworkStream stream;

        static public ConcurrentBag<Session> sessions = new ConcurrentBag<Session>();

        static public bool IsKickerRunning = false; //guards the kicker from endless calls that would crash the server


        static public void InitiateSessionKicker(int seconds)
        {
            if (!IsKickerRunning)
            {
                Thread th = new Thread(() => //runs in the background and checks sessions for expired keep alive time
                {
                startAgain:

                    IsKickerRunning = true;
                    Session.KickIdleSessions(sessions, seconds);
                    Thread.Sleep(2000);

                    goto startAgain;
                });
                th.Start();
            IsKickerRunning = false;
            }
        }

        public string SendMessage(string message)
        {
            TcpReadWrite.WriteToStream(stream, message);
            Thread.Sleep(100);

            string str = TcpReadWrite.ReadFromStream(stream);
            //Console.WriteLine(str);
            return str;
        } //non tokenized
        public string ConnectToComm(string ipAndPort)
        {
            if (ipAndPort == null)
                return "Some values did not pass through";
            string[] split = ipAndPort.Split(':');

            string ip = split[0];
            int port = 10001; //default

            try { port = Int32.Parse(split[1]); }
            catch { }

            try
            {
                client = new TcpClient(ip, port);
                stream = client.GetStream();
            }
            catch
            {
                return "Connection failed";
            }
            Thread.Sleep(50);

            return TcpReadWrite.ReadFromStream(stream);
        }//non tokenized



        //---Tokenized---
        public string SendMessageWithID(string message, string id) //Recieves messages using HttpRequests and pass them through to Lingo using TCP Connection
        {
            if (sessions.Count == 0 || string.IsNullOrEmpty(message) || string.IsNullOrEmpty(id))
                return "Error: Wrong parameters";

            string str = "";
            foreach (Session session in sessions)
            {
                if (session.id == id)
                {
                    TcpReadWrite.WriteToStream(session.stream, message);
                    Thread.Sleep(100);

                    str = TcpReadWrite.ReadFromStream(session.stream);
                    Thread.Sleep(100);

                    session.lastHttpReq = DateTime.Now;

                    Console.WriteLine($"{session.id} - {message}");
                    return str;
                }
            }
            //Console.WriteLine(str);
            return "Error: Your session does not exist";
        }
        public string ConnectToCommWithID(string ipAndPort) //tested
        {
            if (ipAndPort == null)
                return "Some values did not pass through";
            string[] split = ipAndPort.Split(':');

            string ip = split[0];
            int port = 10001; //default

            try { port = Int32.Parse(split[1]); }
            catch { }

            try
            {
                client = new TcpClient(ip, port);
                stream = client.GetStream();
                Session session = new Session(client, stream);
                sessions.Add(session);

                Thread.Sleep(100);
                string temp = TcpReadWrite.ReadFromStream(stream) + "|" + session.id;
                Thread.Sleep(50);

                session.lastHttpReq = DateTime.Now;

                return temp;
            }
            catch
            {
                try
                {
                    stream.Close();
                    client.Close();
                    stream.Dispose();
                    client.Dispose();
                }
                catch { }
                return "Connection faliled";
            }
        }

        public string KeepSessionAlive(string id)
        {
            if (id != null)
            {
                foreach (Session session in sessions)
                {
                    if (session.id == id)
                    {
                        session.lastHttpReq = DateTime.Now;
                        return session.id + " " + session.lastHttpReq.ToString();
                    }
                }
            }

            return "KeepAlive was not saved";
        }

    }
}
