﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Reflection.Emit;

namespace mvcAPI
{
    public class Session
    {

        public TcpClient? client { get; set; }
        public NetworkStream? stream { get; set; }
        public string? id { get; set; }
        public DateTime lastHttpReq { get; set; } //keepAlive data per session object
        public Session(TcpClient client, NetworkStream stream)
        {
            this.client = client;
            this.stream = stream;
            this.id = GenerateRandomString(6);
            this.lastHttpReq = DateTime.Now;
        }
        public Session() { } //exists so static methods can be used without initiantion of an object

        public string GenerateRandomString(int length)
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        static public void KickIdleSessions(ConcurrentBag<Session> sessions, int TimeLimitInSeconds)//static for a main general use. not tested yet
        {
            DateTime now = DateTime.Now;

            foreach (Session session in sessions)
            {
                if (session != null && session.id != null)
                {
                    Session? s = session;

                    TimeSpan timeSpan = now.Subtract(session.lastHttpReq);
                    if (timeSpan.TotalSeconds > TimeLimitInSeconds) //if the seconds between now and last time keepAlive was sent is bigger than the limit
                    {
                        try
                        {
                            if (session.stream != null)
                            {
                                session.stream.Close();
                                //session.stream.Dispose();
                            }
                            if (session.client != null)
                            {
                                session.client.Close();
                                session.client.Dispose();
                            }
                            sessions.TryTake(out s);

                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"user {session.id} is kicked due to keepAlive communication loss");
                            Console.ResetColor();
                        }
                        catch { }
                    }
                }
            }
        }

    }
}
